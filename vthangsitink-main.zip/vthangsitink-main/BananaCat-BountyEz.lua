loadstring(game:HttpGet("https://raw.githubusercontent.com/RedGamer12/TNNP-SYSTEM/refs/heads/main/client/BloxFruit/Bounty_Rewrite-obfuscated.lua"))()

